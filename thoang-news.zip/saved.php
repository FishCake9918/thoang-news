<?php
session_start();
require_once 'config/db.php';
require_once 'config/session.php';

$page_title = 'Đã lưu - Thoáng.vn';
$active_nav = 'saved';

$session_id = session_id();
$filter_cat = $_GET['cat'] ?? 'all';
$search_kw  = trim($_GET['q'] ?? '');

$where = ["a.status = 'Approved'"];
$params = [];

if (isLoggedIn()) {
    $where[] = "b.user_id = ?";
    $params[] = $_SESSION['user_id'];
} else {
    $where[] = "b.session_id = ? AND b.user_id IS NULL";
    $params[] = $session_id;
}

if ($filter_cat !== 'all' && $filter_cat !== '') {
    $where[] = "c.slug = ?";
    $params[] = $filter_cat;
}

if ($search_kw !== '') {
    $where[] = "(a.title LIKE ? OR a.summary LIKE ?)";
    $params[] = "%$search_kw%";
    $params[] = "%$search_kw%";
}

$where_sql = implode(' AND ', $where);

$sql = "
    SELECT
        a.id,
        a.title,
        a.summary,
        a.source AS source_name,
        a.created_at,
        c.slug AS category,
        c.name AS category_name,
        c.color_bg,
        c.color_text,
        MAX(b.created_at) AS saved_at
    FROM bookmarks b
    INNER JOIN articles a ON a.id = b.article_id
    LEFT JOIN categories c ON c.id = a.category_id
    WHERE $where_sql
    GROUP BY a.id, a.title, a.summary, a.source, a.created_at, c.slug, c.name, c.color_bg, c.color_text
    ORDER BY saved_at DESC
";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$saved_articles = $stmt->fetchAll(PDO::FETCH_ASSOC);
$total = count($saved_articles);

$page_css = 'stylesheets/style.css';
include 'partials/header.php';
?>

<div class="secondary-nav">
  <div class="container p-0">
    <a href="saved.php?cat=all" class="<?= $filter_cat === 'all' ? 'active' : '' ?>">Tất cả</a>
    <?php
    $cats = [
        'tech' => 'Công nghệ',
        'biz' => 'Kinh tế',
        'world' => 'Thế giới',
        'sport' => 'Thể thao',
        'life' => 'Đời sống',
        'edu' => 'Giáo dục',
    ];
    foreach ($cats as $key => $label):
    ?>
      <a href="saved.php?cat=<?= urlencode($key) ?>" class="<?= $filter_cat === $key ? 'active' : '' ?>">
        <?= htmlspecialchars($label) ?>
      </a>
    <?php endforeach; ?>
  </div>
</div>

<div class="page-body">
  <div class="container">
    <div class="row justify-content-center">
      <div class="col-lg-9 col-xl-8">
        <div class="filter-bar">
          <form method="GET" action="saved.php">
            <input type="hidden" name="cat" value="<?= htmlspecialchars($filter_cat) ?>">
            <div class="d-flex gap-2 flex-wrap align-items-center">
              <input
                type="text"
                name="q"
                placeholder="Tìm kiếm bài đã lưu..."
                value="<?= htmlspecialchars($search_kw) ?>"
                style="flex:1; min-width:180px;"
              >
              <button type="submit" class="btn-filter">
                <i class="bi bi-search me-1"></i>Tìm kiếm
              </button>
            </div>
          </form>
        </div>

        <div class="d-flex justify-content-between align-items-center mb-3">
          <span class="section-label mb-0">Tin đã lưu (<?= $total ?>)</span>
          <?php if ($total > 0): ?>
            <a href="#" class="text-muted" style="font-size:12px; text-decoration:none;" onclick="deleteAll(); return false;">
              <i class="bi bi-trash3 me-1"></i>Xóa tất cả
            </a>
          <?php endif; ?>
        </div>

        <div class="saved-list" id="savedList">
          <?php if (empty($saved_articles)): ?>
            <div class="empty-state">
              <i class="bi bi-bookmark-x"></i>
              <p>Chưa có bài nào được lưu<?= $search_kw ? ' phù hợp với "' . htmlspecialchars($search_kw) . '"' : '' ?>.</p>
              <a href="index.php" style="font-size:13px; color:var(--navy);">Khám phá tin tức -></a>
            </div>
          <?php else: ?>
            <?php foreach ($saved_articles as $article): ?>
              <?php
              $cat_bg = $article['color_bg'] ?: '#eeeeee';
              $cat_text = $article['color_text'] ?: '#555555';
              $cat_label = $article['category_name'] ?: ($article['category'] ?: 'Tin tức');
              $saved_time = strtotime($article['saved_at']);
              $diff = $saved_time ? time() - $saved_time : 0;
              if ($diff < 3600) {
                  $relative_time = 'Đã lưu ' . max(1, floor($diff / 60)) . ' phút trước';
              } elseif ($diff < 86400) {
                  $relative_time = 'Đã lưu ' . floor($diff / 3600) . ' giờ trước';
              } else {
                  $relative_time = 'Đã lưu ' . floor($diff / 86400) . ' ngày trước';
              }
              ?>
              <div class="saved-card" id="card-<?= (int)$article['id'] ?>">
                <div class="d-flex justify-content-between align-items-start">
                  <span class="card-cat" style="background:<?= htmlspecialchars($cat_bg) ?>;color:<?= htmlspecialchars($cat_text) ?>">
                    <?= htmlspecialchars($cat_label) ?>
                  </span>
                  <button class="btn-remove-saved" title="Bỏ lưu" onclick="removeArticle(<?= (int)$article['id'] ?>)">
                    <i class="bi bi-bookmark-fill"></i>
                  </button>
                </div>

                <h3 class="saved-headline">
                  <a href="article.php?id=<?= (int)$article['id'] ?>"><?= htmlspecialchars($article['title']) ?></a>
                </h3>
                <p class="saved-summary"><?= htmlspecialchars($article['summary']) ?></p>

                <div class="d-flex align-items-center gap-2">
                  <div class="source-dot"><?= htmlspecialchars(strtoupper(substr($article['source_name'] ?: 'N', 0, 2))) ?></div>
                  <div class="source-name"><?= htmlspecialchars($article['source_name'] ?: 'Nguồn tin') ?></div>
                  <div class="source-time ms-2 border-start ps-2"><?= htmlspecialchars($relative_time) ?></div>
                </div>
              </div>
            <?php endforeach; ?>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
function removeArticle(id) {
  if (!confirm('Bỏ lưu bài viết này?')) return;

  fetch('api/saved_actions.php', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({action: 'remove', article_id: id})
  })
  .then(r => r.json())
  .then(data => {
    if (!data.success) {
      alert(data.message || 'Không thể bỏ lưu bài viết.');
      return;
    }

    const card = document.getElementById('card-' + id);
    if (card) card.remove();
    showToast('Đã bỏ lưu bài viết.');
  });
}

function deleteAll() {
  if (!confirm('Xóa tất cả bài đã lưu?')) return;

  fetch('api/saved_actions.php', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({action: 'remove_all'})
  })
  .then(r => r.json())
  .then(data => {
    if (data.success) location.reload();
  });
}

function showToast(msg) {
  const toast = document.createElement('div');
  toast.style.cssText = 'position:fixed;bottom:24px;right:24px;background:#1a2744;color:#fff;padding:10px 20px;border-radius:8px;font-size:13px;z-index:9999;box-shadow:0 4px 12px rgba(0,0,0,0.2);';
  toast.textContent = msg;
  document.body.appendChild(toast);
  setTimeout(() => toast.remove(), 2500);
}
</script>

<?php include 'partials/footer.php'; ?>
